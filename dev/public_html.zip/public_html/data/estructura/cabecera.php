<div id="c1" class="desk">

	<div class="m1">
    
    	<div class="logo">
            <a href="home">
                <img src="imagenes/logo.png?v=<? echo $version;?>" alt="<? echo $empresa_web;?>">
            </a>
        </div>
       
        <div class="menu">

            <ul>

                <li><a href="home">Home</a></li>
                <li><a href="aparts">Aparts</a></li>
                <li><a href="servicios">Servicios</a></li>
                <li><a href="<? echo $google_como_llegar;?>" target="_blank">Como llegar</a></li>
                <li><a href="contacto">Contacto</a></li>
                <li><a href="<? echo $reserva_online;?>" style="color:blue!important;">Reserva online</a></li>

                <li class="btn-phone"><i class="fa fa-phone"></i> <? echo $telefono_web;?></li>
                <li class="btn-whatsapp"><a href="javascript:;" class="whatsapp"><i class="fa fa-whatsapp"></i> <? echo $whatsapp_web;?></a></li>
             
            </ul>  
              
        </div>

    </div>   
     
</div>



<div id="c4" class="mobile">
	

        <div class="b1">
            <a href="home">
                <img src="imagenes/logo-response.png?v=<? echo $version;?>" alt="<? echo $empresa_web;?>">              
            </a>
        </div>
        
        
        <div class="b3">
        
            <div class="d1">    
    
                <div id="nav">
                    <i class="fa fa-bars"></i>
                </div>
    
            </div>
        
        </div>
                                        
        <nav id="menuBox" class="menuBox">
            
            <div class="navlayer">
            
					<div class="navTop">

						<div class="navClose">
							<i class="fa fa-angle-left" aria-hidden="true"></i> 
						</div>

					<div class="clear"></div>
					</div>

 
                      <div class="navCategorias">

                            <li><a href="home"><i class="fa fa-genderless icon"></i> Home</a></li>
                            <li><a href="aparts"><i class="fa fa-genderless icon"></i> Aparts</a></li>
                            <li><a href="servicios"><i class="fa fa-genderless icon"></i> Servicios</a></li>
                            <li><a href="<? echo $google_como_llegar;?>" target="_blank"><i class="fa fa-genderless icon"></i> Cómo llegar</a></li>
                            <li><a href="contacto"><i class="fa fa-genderless icon"></i> Contacto</a></li>
                            <li><a href="<? echo $reserva_online;?>"><i class="fa fa-genderless icon"></i> Reserva online</a></li>
                      
                                    
                      <div class="clear"></div>
                      </div>
                  
                  <div class="clear"></div>
                  </div>
              
            </nav>
            
            
    <div id="c-mask" class="c-mask"></div>
    

</div>

   
<?php

$server="localhost";
$usuario_base="destinar_signos";
$password="kJZ6^!$.-.C-";
$base="destinar_sistema";

/*
$server="localhost";
$usuario_base="root";
$password="";
$base="destinar";
*/
?>